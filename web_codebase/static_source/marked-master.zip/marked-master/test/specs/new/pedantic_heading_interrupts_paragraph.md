---
pedantic: true
---

paragraph before head with hash
#how are you

paragraph before head with equals
how are you again
===========
