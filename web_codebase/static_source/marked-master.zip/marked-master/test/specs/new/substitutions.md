foo␤␤bar

* a *
