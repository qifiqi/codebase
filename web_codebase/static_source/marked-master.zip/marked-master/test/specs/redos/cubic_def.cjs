module.exports = {
  markdown: `[x]:${' '.repeat(1500)}x ${' '.repeat(1500)} x`,
  html: `<p>[x]:${' '.repeat(1500)}x ${' '.repeat(1500)} x</p>`,
};
