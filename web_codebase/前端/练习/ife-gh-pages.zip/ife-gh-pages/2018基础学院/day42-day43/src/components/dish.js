// 菜品类

/**
 * 菜品类
 *
 * @class Dish
 */
class Dish {
  constructor({name, cost, price}) {
    this.name = name;
    this.cost = cost;
    this.price = price;
  }
}

export default Dish