import { Scene, Sprite ,Group} from 'spritejs'

class waiterView {
  constructor() {
    this.waiter = new Sprite('../images/waiter.png');

  }
  
}

export default waiterView
