import "./index.css";

console.log("Hello World");

if (module.hot) {
    module.hot.accept();
}