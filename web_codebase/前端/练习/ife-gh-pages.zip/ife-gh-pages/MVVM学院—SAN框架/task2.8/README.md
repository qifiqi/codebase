# API
## 属性
|名称|类型|必须|默认值|描述|
|:--|:--|:--|:--|:--|
|title|string|false|无|面板标题|
|description|string|false|无|描述|
|open|boolean|false|false|是否打开抽屉|
## 事件
无

## 插槽
|名称|描述|
|:--|:--|
|title|标题插槽|
|description|描述插槽|
|default|内容插槽|